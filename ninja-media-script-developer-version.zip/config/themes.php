<?php

return [

	'themes_folder' => public_path('themes'),
	'publish_assets' => false

];