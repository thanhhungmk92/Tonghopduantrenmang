<?php 
	require(__DIR__ . '/../Autoload.php'); 
	$step = (isset($_GET['step'])) ? $_GET['step'] : 'welcome';
	require('api.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title><?= PRODUCT_TITLE; ?> Installation</title>
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?= URL ?>/assets/style.css">
	<link rel="stylesheet" type="text/css" href="<?= URL ?>/assets/animate.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script>
		function show_loader(message){
			if(typeof(message) != 'undefined'){
				$('#loader').find('p').text(message);
			}
			$('#loader').slideDown();
		}

		function hide_loader(){
			$('#loader').find('p').text('');
			$('#loader').slideUp();
		}
	</script>
</head>
<body>

	<div class="header">
		<img class="logo" src="<?= PRODUCT_LOGO ?>">
	</div>

	<div class="panel">

		<h1><?= PRODUCT_TITLE; ?> Installation<i>Step <?= array_search($step, $steps) + 1; ?> of <?= count($steps); ?></i></h1>
		<h2>
			<?php 
				
				$numSteps = count($steps);
				$i = 0;
				$cur_found = false;
				foreach($steps as $stepper):
					
					if($stepper == $step){
						$step_title = '<strong>' . ucfirst($stepper) . '</strong>';
						$cur_found = true;
					} else {
						if($cur_found){
							$step_title = ucfirst($stepper);
						} else {
							$step_title = '<span class="prev_step">' . ucfirst($stepper) . '</span>';
						}
						
					}

					echo '<a href="' . URL . '?step=' . $stepper . '">' . $step_title . '</a>';
					if(++$i !== $numSteps):
						echo '<span>|</span>';
					endif;

				endforeach; ?>
		</h2>