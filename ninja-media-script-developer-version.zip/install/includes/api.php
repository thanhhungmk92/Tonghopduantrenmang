<?php 

	/********************
	*
	*	database
	*
	********************/

	if($step == 'database' && isset($_POST['db_host']) && isset($_POST['db_name']) && isset($_POST['db_user']) && isset($_POST['db_pass'])){
		$environment = new Environment();
		echo json_encode($environment->writeDB($_POST['db_host'], $_POST['db_name'], $_POST['db_user'], $_POST['db_pass']));
		die();
	}

?>