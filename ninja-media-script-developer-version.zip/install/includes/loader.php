<div id="loader">
	<img src="<?= URL ?>/assets/loading.gif">
	<p></p>
</div>