<?php 

	function getNextStep($step, $copy){
		$next_step = '';
		$break = false;
		foreach($steps as $install_step):

			if($break){ 
				$next_step = $install_step;
				break;
			}
			if($install_step == $step){
				$break = true;
			}

		endforeach;

		echo '<div class="center">
			<a href="<?= URL ?>?step=' . $next_step . '" class="btn btn-success">' . $copy . '</a>
		</div>';
	}
?>