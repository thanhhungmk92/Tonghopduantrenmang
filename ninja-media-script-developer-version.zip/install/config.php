<?php

define('PRODUCT', 'ninja-media-script');
define('PRODUCT_TITLE', 'Ninja Media Script');
define('PRODUCT_LOGO', 'https://s3.amazonaws.com/devdojo/products/downloads/ninja-media-script-logo.png');
define('PRODUCT_API_URL', 'https://devdojo.com/product/api/' . PRODUCT);

$requirements = [
    
    'php' => '7.0.0',
    'extensions' => [
        'openssl',
        'pdo',
        'mbstring',
        'tokenizer',
        'xml',
        'gd'
    ],
    'functions' => [
        'file_get_contents',
        'file_put_contents',
    ],
    'classes' => [
        'ZipArchive'
    ]

];

$requirement_titles = [
    'php' => 'PHP Version',
    'extensions' => 'PHP Extensions Enabled',
    'functions' => 'PHP Functions Available',
    'classes' => 'PHP Classes Available',
];

$steps = ['welcome', 'requirements', 'verify', 'unzip', 'database', 'install'];
