<?php

class Environment{

	public function writeDB($host, $db_name, $db_user, $db_pass){

		$env_file = __DIR__ . '/../application/.env';

        if (file_exists($env_file)) {
        	//$content = file_get_contents($env_file);
        	//echo $content;

        	

        	try{
			    $dbh = new pdo( 'mysql:host=' . $host . ';dbname=' . $db_name,
			                    $db_user,
			                    $db_pass,
			                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			   
			   // make sure the .env file is writable
			   if(!is_writable($env_file)){
					return Helper::message('error', 'Sorry, your .env file does not seem to be writable, please check the permissions on your .env file. Thanks.');
			   }

			   	$data = array(
			   		'APP_URL' => substr(URL, 0, -8),
					'DB_HOST' => $host,
					'DB_DATABASE' => $db_name,
					'DB_USERNAME' => $db_user,
					'DB_PASSWORD' => $db_pass);

				$this->changeEnv($data, $env_file);

			}
			catch(PDOException $ex){
			    return Helper::message('error', 'Could not establish a database connection with those credentials, please verify you have entered them in correctly and try again. Thanks :)');
			}

        	return Helper::message('success', 'Successfully Updated .env');
            //copy($this->envExamplePath, $this->envPath);
        } else {
            return Helper::message('error', '.env file does not exist');
        }

	}

	protected function changeEnv($data = array(), $env_file){
        if(count($data) > 0){

            // Read .env-file
            $env = file_get_contents($env_file);

            // Split string on every " " and write into array
            $env = preg_split('/\s+/', $env);;

            // Loop through given data
            foreach((array)$data as $key => $value){

                // Loop through .env-data
                foreach($env as $env_key => $env_value){

                    // Turn the value into an array and stop after the first split
                    // So it's not possible to split e.g. the App-Key by accident
                    $entry = explode("=", $env_value, 2);

                    // Check, if new key fits the actual .env-key
                    if($entry[0] == $key){
                        // If yes, overwrite it with the new one
                        $env[$env_key] = $key . "=" . $value;
                    } else {
                        // If not, keep the old one
                        $env[$env_key] = $env_value;
                    }
                }
            }

            // Turn the array back to an String
            $env = implode("\n", $env);

            // And overwrite the .env with the new data
            file_put_contents($env_file, $env);
            
            return true;
        } else {
            return false;
        }
    }

}