<?php

class Helper{
	private function __construct() {
    }

	static function message($status, $message){
		return (object) array('status' => $status, 'message' => $message);
	}

	static function getNextStep($url, $steps, $step, $copy){
		$next_step = '';
		$break = false;
		foreach($steps as $install_step):

			if($break){ 
				$next_step = $install_step;
				break;
			}
			if($install_step == $step){
				$break = true;
			}

		endforeach;

		echo '<div class="center">
			<a href="' . $url . '?step=' . $next_step . '" class="btn btn-step">' . $copy . '</a>
		</div>';
	}

}