<?php


class Unzipper{
	

	public function __construct(){
	}

	static function unzip($product){
		$filename = $product . '.zip';
		$destination = '../';
		$source = $filename .'/';

		// Check to see if the file exists for extraction
		if(!file_exists($destination . $filename)){	
		    return Helper::message('error', 'Cannot unzip file ' . $filename . ', because it does not exist');
		}

		//Check that we have permissions to unzip those files
		if(class_exists('ZipArchive')){

			$unzip = new ZipArchive;
			
			$res = $unzip->open($destination . $filename);
			if ($res === TRUE) {
				if (is_writeable($destination)) {
					$unzip->extractTo($destination);
					$unzip->close();

					// unlink the main index.php file
					if(file_exists($destination . 'index.php')){
					    unlink($destination . 'index.php');
					}

					// copy all the files that got unzipped to the folder to the root dir
					self::recursiveCopy($destination . PRODUCT, $destination);

					// Set permissions for storage and bootstrap dir
					self::setPermissions($destination);

					// delete the files that got moved into the folder since they are now in root
					self::recursiveRmdir($destination . PRODUCT);

				  return Helper::message('success', "Successfully unzipped the product");
				} else {
					return Helper::message('error', "Please make sure that this folder is writable");
				}
			} else {
			  return Helper::message('error', "Sorry there appears to be a problem unzipping the file. Please unzip the contents  of $filename and then upload the files to your server.");
			}

		} else {
			return Helper::message('error', "Your hosting provider does not have ZipArchive enabled. Please enable it or unzip the contents  of $filename and then upload the files to your server.");
		}

		

	}

	static function recursiveCopy($src,$dst) { 
	    $dir = opendir($src); 
	    @mkdir($dst); 
	    while(false !== ( $file = readdir($dir)) ) { 
	        if (( $file != '.' ) && ( $file != '..' )) { 
	            if ( is_dir($src . '/' . $file) ) { 
	                self::recursiveCopy($src . '/' . $file,$dst . '/' . $file); 
	            } 
	            else { 
	                copy($src . '/' . $file,$dst . '/' . $file);
	            } 
	        } 
	    } 
	    closedir($dir); 
	}

	static function recursiveRmdir($dir) {
		$files = array_diff(scandir($dir), array('.','..'));
		foreach ($files as $file) {
			(is_dir("$dir/$file")) ? self::recursiveRmdir("$dir/$file") : unlink("$dir/$file");
		}
		return rmdir($dir);
	}

	static function setPermissions($destination){
		chmod($destination . 'application/bootstrap/cache/', 0775);
		chmod($destination . 'application/storage/app/', 0775);
		chmod($destination . 'application/storage/framework/', 0775);
		chmod($destination . 'application/storage/logs/', 0775);
	}

}