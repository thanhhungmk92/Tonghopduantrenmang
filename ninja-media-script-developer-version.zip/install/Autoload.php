<?php

if(file_exists(__DIR__ . '/config.php')){

	require(__DIR__ . '/config.php');
	require('Helper.php');
	require('Unzipper.php');
	require('Requirements.php');
	require('Environment.php');

	$RequestURI = strtok($_SERVER["REQUEST_URI"],'?');
	$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$RequestURI";
	define('URL', rtrim(trim($url, '/'), '/index.php'));
	define('URL_INDEX', trim($url, '/') . '/index.php');

} else {

	die('You need to create your config.php file');

}
