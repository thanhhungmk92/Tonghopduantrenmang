<?php

class Requirements{
	
	private $requirements;

	public function __construct($requirements){

		if(isset($requirements)){
			$this->requirements = $requirements;
		} else {
			// set the default requirements if not set in the config
			$this->requirements = [
				'php' => '5.6.4',
			    'extensions' => [
			        'openssl',
			        'pdo',
			        'mbstring',
			        'tokenizer',
			        'xml'
			    ],
			    'functions' => [
			    	'file_get_contents',
                    'file_put_contents',
			    ],
			    'classes' => [
                    'PDO',
			    	'ZipArchive'
			    ]

			];
		}

	}


	public function check()
    {
        $results = [];
        foreach($this->requirements as $type => $requirement)
        {
            switch ($type) {
            	// check php version
                case 'php':
                    $results['requirements'][$type][$requirement] = true;
                   
                   	if (version_compare(PHP_VERSION, $requirement) < 0) {
                        $results['requirements'][$type][$requirement] = false;
                        $results['errors'] = true;
                    }

                    break;
                // check php extensions
                case 'extensions':
                    foreach($this->requirements[$type] as $requirement)
                    {
                        $results['requirements'][$type][$requirement] = true;
                        if(!extension_loaded($requirement))
                        {
                            $results['requirements'][$type][$requirement] = false;
                            $results['errors'] = true;
                        }
                    }
                    break;

                case 'functions':
                    foreach($this->requirements[$type] as $requirement){
                        $results['requirements'][$type][$requirement] = true;
                        if(!function_exists($requirement)){
                            $results['requirements'][$type][$requirement] = false;
                            $results['errors'] = true;
                        }
                    }
                    break;

                case 'classes':
                    foreach($this->requirements[$type] as $requirement){
                        $results['requirements'][$type][$requirement] = true;
                        if(!class_exists($requirement)){
                            $results['requirements'][$type][$requirement] = false;
                            $results['errors'] = true;
                        }
                    }
                    break;
            }
        }
        return $results;
    }

}