<?php include('includes/header.php'); ?>

	<?php include('steps/' . $step . '.php'); ?>

<?php include('includes/footer.php'); ?>

<?php 
//print_r( Unzipper::unzip(PRODUCT)  );


