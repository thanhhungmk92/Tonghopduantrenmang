<?php 

  $install_finish = file_get_contents(__DIR__."/install_finish.txt");
  $final_step = file_put_contents(__DIR__.'/../../application/routes/web.php', $install_finish.PHP_EOL , FILE_APPEND | LOCK_EX);

 ?>

<p>Fantastic! We are almost done with the installation, we just need to add the data to the database and remove the installer.</p>
<div class="center">
  <a href="<?= URL ?>/finish" class="btn btn-success">Finish the Install</a>
</div>