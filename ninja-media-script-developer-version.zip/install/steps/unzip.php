<?php if(isset($_GET['confirmed'])) :
	$unzipper = Unzipper::unzip(PRODUCT);
	
	if($unzipper->status == 'success'): ?>

		<?php 
			// Remove the zip file
			@unlink('./' . PRODUCT . '.zip'); 
		?>
		<p>Successfully unzipped the application. Next, let's add the database credentials and a few more settings.</p>
		<?php Helper::getNextStep(URL, $steps, $step, 'Next Step'); ?>

	<?php else: ?>
		<p>Sorry, it looks like there was a problem unzipping the application:</p>
		<div class="error-msg animated fadeIn" id="error" style="display:block;">
			<?= $unzipper->message; ?>
		</div>
		<p>You may want to try the installer again or you will have to try one of the alternate ways of installing the script.</p>
	<?php endif; ?>

<?php else : ?>

	<?php ini_set('max_execution_time', 300); ?>
	<p>Unzipping the contents of the <?= PRODUCT_TITLE ?> script.</p>
	<?php include('./includes/loader.php'); ?>
	<script>
		$('document').ready(function(){
			show_loader('Unpacking the script...');
			window.location = '<?= URL ?>?step=unzip&confirmed=true';
		});
	</script>

<?php endif; ?>