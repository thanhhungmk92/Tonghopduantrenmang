<?php

$reqs = new Requirements($requirements);
$requirements = $reqs->check();

?>

<style type="text/css">

ul{
	list-style:none;
	margin-left:0px;
	padding-left:0px;
}

li{
	height:32px;
	line-height:32px;
	margin-bottom:10px;
}
	.circle{
	  fill: none;
	  animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
	  stroke-dasharray: 166;
	  stroke-dashoffset: 166;
	  stroke-width: 2;
	  stroke-miterlimit: 10;
	  background:#000;
	}

	.status {
	  width: 32px;
	  height: 32px;
	  border-radius: 50%;
	  display: block;
	  stroke-width: 2;
	  stroke: #fff;
	  stroke-miterlimit: 10;
	  margin: 0px;
	  margin-right:15px;
	  float:left;
	  box-shadow: inset 0px 0px 0px #000;
	  animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
	}

	.status_icon {
	  transform-origin: 50% 50%;
	  stroke-dasharray: 48;
	  stroke-dashoffset: 48;
	  animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
	}

	.success .circle {
	  stroke: #00BF4A;
	}

	.status.success{
		box-shadow: inset 0px 0px 0px #00BF4A;
		animation: fill_success .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
	}

	.error .circle{
		stroke: #e74c3c;
	}

	.status.error{
		box-shadow: inset 0px 0px 0px #e74c3c;
		animation: fill_error .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
	}

	.requirement{
		display:none;
	}

	@keyframes stroke {
	  100% {
	    stroke-dashoffset: 0;
	  }
	}
	@keyframes scale {
	  0%, 100% {
	    transform: none;
	  }
	  50% {
	    transform: scale3d(1.1, 1.1, 1);
	  }
	}

	@keyframes fill {
	  100% {
	    box-shadow: inset 0px 0px 0px 30px #000;
	  }
	}

	@keyframes fill_success {
	  100% {
	    box-shadow: inset 0px 0px 0px 30px #7ac142;
	  }
	}

	@keyframes fill_error {
	  100% {
	    box-shadow: inset 0px 0px 0px 30px #e74c3c;
	  }
	}

	.requirement_btn{
		display:none;
	}


</style>



	<?php foreach($requirements['requirements'] as $type => $requirement): ?>
		<div class="requirement">
		    <h5><?= (isset($requirement_titles[$type])) ? $requirement_titles[$type] : $type; ?></h5>
		</div>
		    <ul class="list">
		        <?php foreach($requirements['requirements'][$type] as $extention => $enabled): ?>

		        	<div class="requirement">
			            <li class="list__item <?= $enabled ? 'success' : 'error' ?>">

			            	<?php if($enabled == 'success'): ?>
			            	
			            		<svg class="status success" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="circle" cx="26" cy="26" r="25" fill="none"/><path class="status_icon" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/></svg>

			            	<?php else: ?>

			            		<svg class="status error" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="circle" cx="26" cy="26" r="25" fill="none"/><path class="status_icon" fill="none" d="M 16,16 L 36,36"/><path class="status_icon" fill="none" d="M 36,16 L 16,36"/></svg>

			            	<?php endif; ?>

			            	<?= $extention ?> <span class="label label-<?= $enabled ? 'success' : 'error' ?>"><?= $enabled ? 'pass' : 'fail' ?></span>
			            </li>
			        </div>
		        
		        <?php endforeach; ?>
		    </ul>
	<?php endforeach; ?>

	<?php if ( ! isset($requirements['errors']) ): ?>
		<div class="requirement_btn animated slideInUp">
			<?php Helper::getNextStep(URL, $steps, $step, 'Next Step'); ?>
		</div>
	<?php else: ?>
		<div class="requirement_btn error animated slideInUp">
			<div class="warning">
				Your server does not meet all the minimum requirements above. It is recommended that you meet all the requirements; however, you can still continue continue with the installation and keep your fingers crossed that everything goes well.
			</div>
			<?php Helper::getNextStep(URL, $steps, $step, 'Continue Anyway'); ?>
		</div>
	<?php endif; ?>

<script>

$('document').ready(function(){
	var requirements = $( ".requirement" );
	var len = requirements.length;
	requirements.each(function( index ) {
		var that = this;
		var cur_index = index;
		setTimeout(function(){
			$(that).addClass('animated fadeInUp');
			$(that).show();
			if(cur_index == len - 1){
				$('.requirement_btn').show();
			}
			$("html, body").animate({ scrollTop: $(document).height()-$(window).height() });
			console.log($(this));
		}, index*450);
	});
});

</script>