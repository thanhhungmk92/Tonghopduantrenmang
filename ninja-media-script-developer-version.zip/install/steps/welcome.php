<h3>Howdy!</h3>
<p>In this installation wizard we will check for system requirements, download and unzip the latest version, check file permissions, add site settings, and then complete the installation.</p>
<p>So, how about we get started ;)</p>
<?php Helper::getNextStep(URL, $steps, $step, 'Start Installation'); ?>