<?php if(isset($_POST['product_dnl'])): ?>

	<?php

		$context = stream_context_create(array( 
		    'http' => array( 
		        'timeout' => 1800 
		        ) 
		    ) 
		);

		$purchase_code = $_POST['pcode'];

		$headers = @get_headers($_POST['product_dnl']);
		if(strpos($headers[0],'200')===false){ ?>

			<div class="error-msg animated fadeIn" id="error" style="display:block;">Sorry, the download URL could not be found (url: "<?= $_POST['product_dnl']; ?>"). Please make sure you are connected to the internet. If you still can not download the script please open a ticket and we will get this resolved ASAP, thanks.</div>

		<?php } else {
			ini_set('memory_limit', '-1');
			
			$file = file_get_contents($_POST['product_dnl'], 0, $context);
			file_put_contents(__DIR__.'/../../' . PRODUCT . '.zip', $file, false, $context);
			echo '<script>window.location="' . URL . '?step=unzip";</script>';
		}
	?>

<?php else: ?>
	<p>Before installing the latest version of the <?= PRODUCT_TITLE ?> app, we need to verify your purchase. Enter your <b>purchase code</b> below and then click verify.</p>
	<div class="error-msg animated fadeIn" id="error"></div>
	<input type="text" name="code" id="code" placeholder="License Key">
	<div class="center">
		<div class="btn btn-success" id="download" style="margin-top:0px;">Verify</div>
	</div>
	<?php include('./includes/loader.php'); ?>
	<div class="more_info">
		<small>Not sure where to get your purchase code? Visit your download section and click on download License & purchase code.</small>
		<br><br>
		<img src="<?= URL ?>/assets/purchase-code.jpg">
	</div>

	<form id="dnl_form" style="display:none" action="<?= URL_INDEX ?>?step=verify" method="POST">
		<input type="hidden" name="product_dnl" id="product_dnl" value="">
		<input type="hidden" name="pcode" id="pcode" value="">
	</form>

	<script>
		$('document').ready(function(){
			$('input').focus();
			$('#download').click(function(){
				show_loader('Verifying Your Purchase Code');
				$.getJSON('<?= PRODUCT_API_URL ?>/verify?code=' + $('#code').val() + '&url=' + window.location.href, function(data){
					if(data.status == 'error'){
						hide_loader();
						$('#error').text(data.message);
						$('.error-msg').show();
					} else {
						show_loader('Purchase Code Verified. Retrieving The Latest Version.');

						var messages = [
								'Friendly reminder: don\'t share your purchase code with anyone.',
								'This process can take a little longer based on your internet connection speed.',
								'Your Installation should begin here shortly.',
								'That\'s a nice shirt you\'re wearing by the way ;)',
								'Retrieving the latest version of the script.',
								'This download process shouldn\'t be much longer...',
								'Thanks for your patience :)',
								'You\'re awesome! Thanks for being patient :)'
							];
						setInterval(function(){
							show_loader(messages[Math.floor(Math.random() * messages.length)]);
						}, 10000);
						$('#product_dnl').val(data.url);
						$('#pcode').val($('#code').val());
						$('#dnl_form').submit();
					}
				});
			});
		});
	</script>
<?php endif; ?>