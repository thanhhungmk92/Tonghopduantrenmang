<p style="margin-left:4px;">Before we complete the installation process we will need to add your database credentials below:</p>
<div class="error-msg animated fadeIn" id="error"></div>
<?php include('./includes/loader.php'); ?>
<style>
	#loader{
		margin-bottom:14px;
	}
</style>
<input type="text" name="db_host" id="db_host" placeholder="Database Host">
<input type="text" name="db_name" id="db_name" placeholder="Database Name">
<input type="text" name="db_user" id="db_user" placeholder="Database User">
<input type="password" name="db_pass" id="db_pass" placeholder="Database Password">
<div class="center">
	<div class="btn btn-success" id="check_db">Verify Database Credentials</div>
</div>

<script>
	$('document').ready(function(){
		$('#check_db').click(function(){
			show_loader('Verifying Database Credentials...');
			setTimeout(function(){
				$.post('<?= URL_INDEX ?>?step=database', { db_host: $('#db_host').val(), db_name: $('#db_name').val(), db_user: $('#db_user').val(), db_pass: $('#db_pass').val() }, function(data){
					data = JSON.parse(data);
					if(data.status == 'error'){
						hide_loader();
						$('#error').text(data.message);
						$('.error-msg').show();
					} else {
						hide_loader();
						window.location = '<?= URL ?>?step=install';
					}
					console.log(data);
				});
			}, 1000);
		});

		$('#db_host, #db_name, #db_user, #db_pass').keypress(function(e) {
		    if(e.which == 13) {
		    	$('#check_db').trigger('click');
		    }
		});
	});
</script>