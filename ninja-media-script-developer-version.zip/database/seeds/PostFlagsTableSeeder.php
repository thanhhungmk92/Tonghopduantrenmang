<?php

use Illuminate\Database\Seeder;

class PostFlagsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('post_flags')->delete();
        
        
        
    }
}