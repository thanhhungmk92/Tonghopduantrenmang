<?php

use Illuminate\Database\Seeder;

class OauthFacebookTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('oauth_facebook')->delete();
        
        
        
    }
}