$('document').ready(function(){
	if($('#filemanager').length){
		$('body').addClass('filemanager');
	}
});